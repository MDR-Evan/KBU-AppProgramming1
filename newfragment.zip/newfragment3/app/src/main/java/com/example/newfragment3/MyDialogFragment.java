package com.example.newfragment3;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class MyDialogFragment extends DialogFragment {

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());

        // 다이얼로그의 타이틀과 메시지 설정
        builder.setTitle("DialogFragment")
                .setMessage("DialogFragment 내용이 잘 보이지요")
                .setPositiveButton("OK", (dialog, which) -> dismiss());

        return builder.create(); // AlertDialog 반환
    }
}

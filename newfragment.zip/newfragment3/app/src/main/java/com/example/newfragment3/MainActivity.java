package com.example.newfragment3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.ListFragment;
import androidx.fragment.app.DialogFragment;


public class MainActivity extends AppCompatActivity implements MyListFragment.OnItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button listFragmentButton = findViewById(R.id.list_fragment_button);
        Button dialogFragmentButton = findViewById(R.id.dialog_fragment_button);
        Button fragmentButton = findViewById(R.id.fragment_button);

        listFragmentButton.setOnClickListener(v -> replaceFragment(new MyListFragment()));

        dialogFragmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDialogFragment dialogFragment = new MyDialogFragment();
                dialogFragment.show(getSupportFragmentManager(), "dialog");
            }
        });

        fragmentButton.setOnClickListener(v -> replaceFragment(new ThreeFragment()));

    }
    @Override
    public void onItemSelected(String item) {
        // 선택된 항목 처리
        Toast.makeText(this, "선택된 항목: " + item, Toast.LENGTH_SHORT).show();
    }

    private void replaceFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit();
    }
}

package com.example.newfragment;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements PlanetListFragment.OnPlanetSelectedListener {

    private TextView selectedItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        selectedItem = findViewById(R.id.selected_item);

        // Fragment 추가
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new PlanetListFragment())
                    .commit();
        }
    }

    @Override
    public void onPlanetSelected(String planet) {
        selectedItem.setText(planet);
    }
}

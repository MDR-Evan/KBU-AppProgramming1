package com.example.newfragment;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.ListFragment;

public class PlanetListFragment extends ListFragment {

    private OnPlanetSelectedListener callback;

    // 인터페이스 정의
    public interface OnPlanetSelectedListener {
        void onPlanetSelected(String planet);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        // 콜백 초기화
        if (context instanceof OnPlanetSelectedListener) {
            callback = (OnPlanetSelectedListener) context;
        } else {
            throw new ClassCastException(context.toString() + " must implement OnPlanetSelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        // 리스트 항목 데이터
        String[] planets = {"Sun", "Mercury", "Venus", "Earth", "Mars", "Jupiter",
                "Saturn", "Uranus", "Neptune", "Pluto"};

        // 한국어 번역 데이터
        String[] planetTranslations = {"태양", "수성", "금성", "지구", "화성", "목성",
                "토성", "천왕성", "해왕성", "명왕성"};

        // 어댑터 설정
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, planets);
        setListAdapter(adapter);

        // 리스트 항목 클릭 리스너
        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedPlanet = planets[position];
                String translatedPlanet = planetTranslations[position];
                callback.onPlanetSelected(translatedPlanet);
            }
        });
    }
}
